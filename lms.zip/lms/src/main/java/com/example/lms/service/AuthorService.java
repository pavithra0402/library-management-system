package com.example.lms.service;

import com.example.lms.entity.Author;
import com.example.lms.repo.AuthorRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AuthorService {

    @Autowired
    private AuthorRepo authorRepo;

    public List<Author> getAllAuthors() {
        return authorRepo.findAll();
    }

    public Author getAuthorById(int id) {
        return authorRepo.findById(id)
                .orElseThrow(() -> new RuntimeException("Given id is incorrect"));
    }

    public Author saveOrUpdateAuthor (Author author) {
        return authorRepo.save(author);
    }

    public void deleteAuthorById(int id) {
        authorRepo.findById(id).orElseThrow(() -> new RuntimeException("Given id is incorrect"));

        authorRepo.deleteById(id);
    }
}
