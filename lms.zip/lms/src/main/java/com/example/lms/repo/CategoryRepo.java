package com.example.lms.repo;

import com.example.lms.entity.category;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CategoryRepo extends JpaRepository<category, Integer> {

}
